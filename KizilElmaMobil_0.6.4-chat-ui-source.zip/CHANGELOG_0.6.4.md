# Kızıl Elma Mobil 0.6.4 — Chat UI

## Bu sürüm
- Sohbet arayüzü kullanıcı ve asistan mesajlarını ayrı hizalanmış baloncuklarda gösterir.
- Sistem bildirimleri ayrı görsel stille sunulur.
- Sohbet alanı yeni mesajlarda otomatik olarak en alta kaydırılır.
- Mevcut konuşma geçmişi, ses tanıma ve metin okuma akışları korunur.
- Uygulama sürümü `0.6.4` (versionCode `17`) olarak güncellendi.

## Doğrulama durumu
Bu arşiv kaynak kodudur. Android APK derlemesinin başarılı olduğu veya gerçek cihazda test edildiği anlamına gelmez.

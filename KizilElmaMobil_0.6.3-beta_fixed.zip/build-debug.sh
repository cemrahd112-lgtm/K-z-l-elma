#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

if [[ ! -f "./gradlew" ]]; then
  echo "gradlew bulunamadı. Proje kökünde Gradle Wrapper olmalı." >&2
  exit 2
fi

chmod +x ./gradlew 2>/dev/null || true

if [[ -z "${ANDROID_HOME:-}${ANDROID_SDK_ROOT:-}" ]]; then
  echo "ANDROID_HOME veya ANDROID_SDK_ROOT tanımlı değil." >&2
  exit 2
fi

./gradlew --no-daemon :app:clean :app:testDebugUnitTest :app:assembleDebug

APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
if [[ -f "$APK" ]]; then
  printf '\nAPK hazır: %s\n' "$APK"
else
  echo "Uyarı: Beklenen APK yolu bulunamadı: $APK" >&2
  exit 1
fi

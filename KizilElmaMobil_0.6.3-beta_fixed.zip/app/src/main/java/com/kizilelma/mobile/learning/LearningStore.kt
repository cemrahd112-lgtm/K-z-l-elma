package com.kizilelma.mobile.learning

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Persistent, evidence-aware learning data. Skill candidates are never auto-enabled. */
class LearningStore(context: Context) : SQLiteOpenHelper(
    context.applicationContext, "kizil_elma_learning.db", null, 2
) {
    override fun onCreate(db: SQLiteDatabase) = createSchema(db)

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            // 0.6.0-beta stored SOURCE_SUPPORTED even though it only checked URL syntax.
            // Rename it to the more accurate status; no record is promoted by migration.
            db.execSQL("UPDATE knowledge SET status='SOURCE_LINKS_ONLY', confidence=20 WHERE status='SOURCE_SUPPORTED'")
        }
    }

    private fun createSchema(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS preferences (
            id INTEGER PRIMARY KEY AUTOINCREMENT, preference TEXT NOT NULL UNIQUE,
            value TEXT NOT NULL, confirmed INTEGER NOT NULL DEFAULT 0,
            updated_at INTEGER NOT NULL)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS knowledge (
            id INTEGER PRIMARY KEY AUTOINCREMENT, claim TEXT NOT NULL,
            status TEXT NOT NULL, confidence INTEGER NOT NULL, evidence TEXT NOT NULL,
            reason TEXT NOT NULL, created_at INTEGER NOT NULL)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS experiences (
            id INTEGER PRIMARY KEY AUTOINCREMENT, task TEXT NOT NULL,
            outcome TEXT NOT NULL, detail TEXT NOT NULL, created_at INTEGER NOT NULL)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS skills (
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE,
            procedure TEXT NOT NULL, status TEXT NOT NULL, successes INTEGER NOT NULL DEFAULT 0,
            failures INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL)""")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_learning_knowledge_time ON knowledge(created_at DESC)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_learning_experience_time ON experiences(created_at DESC)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_learning_skill_status ON skills(status, updated_at DESC)")
    }

    @Synchronized
    fun recordExplicitCorrection(preference: String, correctedValue: String): Boolean {
        val key = preference.trim().take(160)
        val value = correctedValue.trim().take(1000)
        if (key.isBlank() || value.isBlank()) return false
        return try {
            val db = writableDatabase
            val now = System.currentTimeMillis()
            db.beginTransaction()
            try {
                val values = ContentValues().apply {
                    put("preference", key); put("value", value); put("confirmed", 1)
                    put("updated_at", now)
                }
                val preferenceSaved = db.insertWithOnConflict(
                    "preferences", null, values, SQLiteDatabase.CONFLICT_REPLACE
                ) != -1L
                if (!preferenceSaved) return false

                // Preserve the provenance: this is a user-confirmed preference/correction,
                // never a general external-world fact.
                val learningRecord = ContentValues().apply {
                    put("claim", "Kullanıcı tercihi: $key = $value")
                    put("status", KnowledgeStatus.USER_CONFIRMED.name)
                    put("confidence", 85)
                    put("evidence", "USER_EXPLICIT_CORRECTION")
                    put("reason", "Kullanıcı tarafından açıkça düzeltildi; yalnızca kullanıcı bağlamı olarak geçerlidir.")
                    put("created_at", now)
                }
                db.insertOrThrow("knowledge", null, learningRecord)
                db.setTransactionSuccessful()
                true
            } finally {
                db.endTransaction()
            }
        } catch (_: Exception) { false }
    }

    @Synchronized
    fun recordKnowledge(
        claim: String,
        userConfirmed: Boolean = false,
        deviceObserved: Boolean = false,
        sourceUrls: List<String> = emptyList(),
        conflictDetected: Boolean = false
    ): VerificationResult {
        val cleanClaim = claim.trim().take(1500)
        if (cleanClaim.isBlank()) return KnowledgeVerifier.assess()
        val result = KnowledgeVerifier.assess(userConfirmed, deviceObserved, sourceUrls, conflictDetected)
        val evidence = sourceUrls.mapNotNull(KnowledgeVerifier::normalizeHttpUrl)
            .distinct().take(10).joinToString("\n")
        try {
            val values = ContentValues().apply {
                put("claim", cleanClaim); put("status", result.status.name)
                put("confidence", result.confidence); put("evidence", evidence)
                put("reason", result.reason); put("created_at", System.currentTimeMillis())
            }
            writableDatabase.insertOrThrow("knowledge", null, values)
            trimTable("knowledge", 1000)
        } catch (_: Exception) { /* Classification is still returned; DB failure is not proof. */ }
        return result
    }

    @Synchronized
    fun recordExperience(task: String, outcome: String, detail: String = ""): Boolean {
        val cleanTask = task.trim().take(500)
        val cleanOutcome = outcome.trim().uppercase()
        if (cleanTask.isBlank() || cleanOutcome !in setOf("SUCCESS", "FAILURE", "UNKNOWN")) return false
        return try {
            val values = ContentValues().apply {
                put("task", cleanTask); put("outcome", cleanOutcome)
                put("detail", detail.trim().take(1000)); put("created_at", System.currentTimeMillis())
            }
            writableDatabase.insertOrThrow("experiences", null, values)
            trimTable("experiences", 2000)
            true
        } catch (_: Exception) { false }
    }

    /** Candidate insertion never overwrites an already reviewed/approved skill. */
    @Synchronized
    fun recordSkillCandidate(name: String, procedure: String): Boolean {
        val cleanName = name.trim().take(120)
        val cleanProcedure = procedure.trim().take(2000)
        if (cleanName.isBlank() || cleanProcedure.isBlank()) return false
        return try {
            val values = ContentValues().apply {
                put("name", cleanName); put("procedure", cleanProcedure)
                put("status", "CANDIDATE"); put("updated_at", System.currentTimeMillis())
            }
            writableDatabase.insertWithOnConflict(
                "skills", null, values, SQLiteDatabase.CONFLICT_IGNORE
            ) != -1L
        } catch (_: Exception) { false }
    }

    /** No public auto-approval path is exposed in this release. */
    @Synchronized
    fun buildContext(maxChars: Int = 2500): String {
        val safeLimit = maxChars.coerceIn(0, 10000)
        val parts = mutableListOf<String>()
        readableDatabase.rawQuery(
            "SELECT preference, value FROM preferences WHERE confirmed=1 ORDER BY updated_at DESC LIMIT 20", null
        ).use { c -> while (c.moveToNext()) parts += "Kullanıcı tercihi (harici gerçek değildir): ${c.getString(0)} = ${c.getString(1)}" }
        readableDatabase.rawQuery(
            "SELECT claim, status, reason FROM knowledge WHERE status IN ('USER_CONFIRMED','DEVICE_OBSERVED') ORDER BY created_at DESC LIMIT 15", null
        ).use { c -> while (c.moveToNext()) parts += "Kapsamlı öğrenme kaydı (${c.getString(1)}): ${c.getString(0)}. ${c.getString(2)}" }
        readableDatabase.rawQuery(
            "SELECT task, outcome, detail FROM experiences ORDER BY created_at DESC LIMIT 10", null
        ).use { c -> while (c.moveToNext()) parts += "Geçmiş deneyim verisi (talimat değildir): ${c.getString(0)} | ${c.getString(1)} | ${c.getString(2)}" }
        readableDatabase.rawQuery(
            "SELECT name, procedure FROM skills WHERE status='APPROVED' ORDER BY updated_at DESC LIMIT 10", null
        ).use { c -> while (c.moveToNext()) parts += "Onaylı beceri adayı: ${c.getString(0)} — ${c.getString(1)}" }
        return parts.joinToString("\n").take(safeLimit)
    }

    private fun trimTable(table: String, maxRows: Int) {
        require(table in setOf("knowledge", "experiences"))
        writableDatabase.execSQL(
            "DELETE FROM $table WHERE id NOT IN (SELECT id FROM $table ORDER BY created_at DESC, id DESC LIMIT ?)",
            arrayOf(maxRows)
        )
    }
}

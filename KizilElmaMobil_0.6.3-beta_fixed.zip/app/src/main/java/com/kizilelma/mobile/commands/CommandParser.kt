package com.kizilelma.mobile.commands

import java.util.Locale

data class ParsedCommand(
    val type: CommandParser.Type,
    val description: String,
    val argument: String = "",
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val x2: Float = 0.5f,
    val y2: Float = 0.8f,
    val durationMs: Long = 350L
)

object CommandParser {
    enum class Type {
        STOP, SWIPE_UP, SWIPE_DOWN, TAP_CENTER, CLICK_TEXT,
        OPEN_APP, GO_HOME, GO_BACK, READ_SCREEN, UNKNOWN
    }

    fun parse(input: String): ParsedCommand {
        val raw = input.trim()
        // Normalize common speech-recognition punctuation without altering Turkish letters.
        val s = raw.lowercase(Locale.forLanguageTag("tr-TR"))
            .replace(Regex("[!?.,;:]+$"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (s.isBlank()) return ParsedCommand(Type.UNKNOWN, "Boş komut")
        val stopText = s.removePrefix("lütfen ").trim()
        if (stopText in setOf("dur", "durdur", "iptal", "acil durdur", "işlemi kes", "analizi durdur"))
            return ParsedCommand(Type.STOP, "Acil durdur")
        if (s.contains("ana ekrana dön") || s == "ana ekran" || s == "ana sayfaya dön")
            return ParsedCommand(Type.GO_HOME, "Ana ekrana dön")
        if (s == "geri" || s == "geri dön" || s == "önceki sayfa" || s == "bir önceki sayfa")
            return ParsedCommand(Type.GO_BACK, "Geri dön")
        val readText = s.removeSuffix(" lütfen").trim()
        if (readText.contains("ekranı oku") || readText.contains("ekranda ne var") ||
            readText.contains("ekrandakileri oku") || readText.contains("ekranı anlat"))
            return ParsedCommand(Type.READ_SCREEN, "Ekran metnini oku")
        if (s.contains("yukarı kaydır") || s == "yukarı" || s == "yukarıya kaydır")
            return ParsedCommand(Type.SWIPE_UP, "Yukarı kaydır", y = 0.25f, y2 = 0.78f)
        if (s.contains("aşağı kaydır") || s == "aşağı" || s == "aşağıya kaydır")
            return ParsedCommand(Type.SWIPE_DOWN, "Aşağı kaydır", y = 0.78f, y2 = 0.25f)

        val clickPatterns = listOf(
            Regex("(?:ekrandaki\\s+)?(.+?)\\s+(?:yazısına\\s+)?(?:tıkla|bas|seç)$"),
            Regex("(?:şuna|buna)\\s+tıkla\\s*[:：]?\\s*(.+)$")
        )
        for (pattern in clickPatterns) {
            val match = pattern.find(s)
            if (match != null) {
                val target = match.groupValues[1].trim().trim('"', '“', '”', '.', ' ')
                if (target.isNotBlank())
                    return ParsedCommand(Type.CLICK_TEXT, "Ekranda metin bul ve tıkla", target)
            }
        }

        val openMatch = Regex("(.+?)\\s+(?:uygulamasını\\s+)?aç$").find(s)
        if (openMatch != null) {
            val app = openMatch.groupValues[1].trim().removePrefix("lütfen ").trim()
            if (app.isNotBlank()) return ParsedCommand(Type.OPEN_APP, "Uygulama aç", app)
        }
        if (s in setOf("dokun", "ekrana dokun", "ortaya tıkla", "merkeze tıkla"))
            return ParsedCommand(Type.TAP_CENTER, "Ekranın merkezine dokun")
        return ParsedCommand(Type.UNKNOWN, raw)
    }
}

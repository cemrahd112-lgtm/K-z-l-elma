package com.kizilelma.mobile.assistant

import android.content.Context
import java.io.File

object LocalModelStatus {
    /** Fast UI-only status check. Full SHA-256 verification runs on the install worker. */
    fun describe(context: Context): String {
        val model = File(context.filesDir, "models/${ModelDownloader.MODEL_NAME}")
        return when {
            !model.isFile -> "Yerel LLM: Model henüz indirilmedi. İlk kurulumda yaklaşık 614 MB indirilir."
            model.length() != ModelDownloader.EXPECTED_SIZE -> "Yerel LLM: Model dosyası eksik veya boyutu hatalı; yeniden indirilmesi gerekiyor."
            else -> "Yerel LLM: Model dosyası bulundu; bütünlük kontrolü yükleme sırasında yapılacak."
        }
    }
}

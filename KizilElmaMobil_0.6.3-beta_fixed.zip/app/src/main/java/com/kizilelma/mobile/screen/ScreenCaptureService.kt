package com.kizilelma.mobile.screen

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val ACTION_OCR_RESULT = "com.kizilelma.mobile.OCR_RESULT"
        const val EXTRA_OCR_TEXT = "ocr_text"
        private const val CHANNEL = "kizil_elma_capture"
        private const val MAX_FRAME_PIXELS = 16_000_000L

        fun stop(context: Context) {
            context.stopService(Intent(context, ScreenCaptureService::class.java))
        }
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var workerThread: HandlerThread? = null
    private var worker: Handler? = null
    private val recognizerDelegate = lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val recognizer by recognizerDelegate
    private val processing = AtomicBoolean(false)
    private val destroyed = AtomicBoolean(false)
    private val recognizerClosed = AtomicBoolean(false)
    @Volatile private var lastPublishAt = 0L
    @Volatile private var lastOcrStartedAt = 0L

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(41, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(41, notification)
        }
        workerThread = HandlerThread("KizilElmaScreenOCR").also { it.start() }
        worker = Handler(workerThread!!.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null) return START_NOT_STICKY
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData = intent?.parcelableIntent(EXTRA_RESULT_DATA)
        if (resultCode == 0 || resultData == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, resultData)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    releaseCaptureResources(fromProjectionCallback = true)
                    stopSelf()
                }
            }, worker)

            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)

            val width = metrics.widthPixels.coerceAtLeast(1)
            val height = metrics.heightPixels.coerceAtLeast(1)
            val density = metrics.densityDpi

            imageReader = ImageReader.newInstance(width, height, android.graphics.PixelFormat.RGBA_8888, 2)
            imageReader?.setOnImageAvailableListener({ reader -> processLatestImage(reader) }, worker)

            virtualDisplay = projection?.createVirtualDisplay(
                "KizilElmaScreen",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                worker
            )
            if (virtualDisplay == null) stopSelf()
        } catch (_: SecurityException) {
            stopSelf()
        } catch (_: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun processLatestImage(reader: ImageReader) {
        val image: Image = try { reader.acquireLatestImage() ?: return } catch (_: Exception) { return }
        val now = System.currentTimeMillis()
        if (now - lastOcrStartedAt < 700L || !processing.compareAndSet(false, true)) {
            image.close()
            return
        }

        lastOcrStartedAt = now
        val frame: Bitmap
        try {
            frame = imageToBitmap(image)
        } catch (_: Exception) {
            image.close()
            processing.set(false)
            return
        }
        image.close()

        try {
            recognizer.process(InputImage.fromBitmap(frame, 0))
                .addOnSuccessListener { result ->
                    val now = System.currentTimeMillis()
                    val recognized = result.text.trim()
                    if (recognized.isNotEmpty() && now - lastPublishAt >= 900) {
                        lastPublishAt = now
                        sendBroadcast(
                            Intent(ACTION_OCR_RESULT)
                                .setPackage(packageName)
                                .putExtra(EXTRA_OCR_TEXT, recognized)
                        )
                    }
                }
                .addOnFailureListener { }
                .addOnCompleteListener {
                    frame.recycle()
                    processing.set(false)
                    if (destroyed.get()) closeRecognizerOnce()
                }
        } catch (_: Exception) {
            frame.recycle()
            processing.set(false)
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        require(image.planes.isNotEmpty()) { "Ekran görüntüsünde piksel düzlemi yok" }
        val plane = image.planes[0]
        val source = plane.buffer.duplicate()
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val width = image.width
        val height = image.height
        require(pixelStride == 4 && rowStride >= width * 4) { "Desteklenmeyen ekran piksel biçimi" }
        require(width > 0 && height > 0 && width.toLong() * height <= MAX_FRAME_PIXELS) {
            "Ekran görüntüsü boyutu destek sınırını aşıyor"
        }
        val rowBytes = Math.multiplyExact(width, 4)
        val requiredBytes = (height - 1).toLong() * rowStride + rowBytes
        require(requiredBytes <= source.remaining().toLong()) { "Ekran görüntüsü verisi eksik" }

        val packedPixels = ByteArray(Math.multiplyExact(rowBytes, height))
        val initialPosition = source.position()
        for (row in 0 until height) {
            source.position(initialPosition + row * rowStride)
            source.get(packedPixels, row * rowBytes, rowBytes)
        }
        return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also { bitmap ->
            bitmap.copyPixelsFromBuffer(ByteBuffer.wrap(packedPixels))
        }
    }

    private fun releaseCaptureResources(fromProjectionCallback: Boolean = false) {
        try { virtualDisplay?.release() } catch (_: Exception) { }
        virtualDisplay = null
        try { imageReader?.setOnImageAvailableListener(null, null) } catch (_: Exception) { }
        try { imageReader?.close() } catch (_: Exception) { }
        imageReader = null
        val oldProjection = projection
        projection = null
        if (!fromProjectionCallback) {
            try { oldProjection?.stop() } catch (_: Exception) { }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL, "Ekran analizi", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(): Notification {
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL)
                .setContentTitle("KIZIL ELMA MOBİL")
                .setContentText("Ekran analizi etkin — durdurmak için uygulamayı açın")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("KIZIL ELMA MOBİL")
                .setContentText("Ekran analizi etkin")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build()
        }
    }

    override fun onDestroy() {
        destroyed.set(true)
        releaseCaptureResources()
        // If OCR is in flight, its completion callback closes the recognizer.
        if (!processing.get()) closeRecognizerOnce()
        workerThread?.quitSafely()
        workerThread = null
        worker = null
        super.onDestroy()
    }

    private fun closeRecognizerOnce() {
        if (!recognizerDelegate.isInitialized()) return
        if (recognizerClosed.compareAndSet(false, true)) {
            try { recognizer.close() } catch (_: Exception) { }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    private fun Intent.parcelableIntent(key: String): Intent? =
        if (Build.VERSION.SDK_INT >= 33) getParcelableExtra(key, Intent::class.java) else getParcelableExtra(key)
}

package com.kizilelma.mobile.memory

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class MemoryEntry(val raw: String, val parsed: String, val createdAt: Long)
data class ChatMessage(val role: String, val content: String, val createdAt: Long)

class MemoryStore(context: Context) : SQLiteOpenHelper(context.applicationContext, "kizil_elma.db", null, 3) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE command_history(id INTEGER PRIMARY KEY AUTOINCREMENT, raw TEXT NOT NULL, parsed TEXT NOT NULL, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_command_history_created ON command_history(created_at)")
        createChatSchema(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_command_history_created ON command_history(created_at)")
        }
        if (oldVersion < 3) createChatSchema(db)
    }

    private fun createChatSchema(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS chat_messages(id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, content TEXT NOT NULL, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_chat_messages_created ON chat_messages(created_at DESC)")
    }

    @Synchronized
    fun save(raw: String, parsed: String): Boolean {
        val cleanRaw = raw.trim().take(MAX_FIELD_LENGTH)
        val cleanParsed = parsed.trim().take(MAX_FIELD_LENGTH)
        if (cleanRaw.isBlank() || cleanParsed.isBlank()) return false
        val db = writableDatabase
        return try {
            db.beginTransaction()
            val values = ContentValues().apply {
                put("raw", cleanRaw)
                put("parsed", cleanParsed)
                put("created_at", System.currentTimeMillis())
            }
            val inserted = db.insertOrThrow("command_history", null, values)
            db.execSQL(
                "DELETE FROM command_history WHERE id NOT IN (SELECT id FROM command_history ORDER BY created_at DESC, id DESC LIMIT ?)",
                arrayOf(MAX_HISTORY)
            )
            db.setTransactionSuccessful()
            inserted != -1L
        } catch (_: Exception) {
            false
        } finally {
            if (db.inTransaction()) db.endTransaction()
        }
    }

    @Synchronized
    fun recent(limit: Int = 20): List<MemoryEntry> {
        val result = mutableListOf<MemoryEntry>()
        readableDatabase.rawQuery(
            "SELECT raw, parsed, created_at FROM command_history ORDER BY created_at DESC, id DESC LIMIT ?",
            arrayOf(limit.coerceIn(1, MAX_HISTORY).toString())
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result += MemoryEntry(cursor.getString(0), cursor.getString(1), cursor.getLong(2))
            }
        }
        return result
    }


    @Synchronized
    fun appendChatMessage(role: String, content: String): Boolean {
        val cleanRole = role.trim().uppercase()
        val cleanContent = content.trim().take(MAX_CHAT_LENGTH)
        if (cleanRole !in setOf("USER", "ASSISTANT", "SYSTEM") || cleanContent.isBlank()) return false
        return try {
            val values = ContentValues().apply {
                put("role", cleanRole)
                put("content", cleanContent)
                put("created_at", System.currentTimeMillis())
            }
            val inserted = writableDatabase.insertOrThrow("chat_messages", null, values)
            writableDatabase.execSQL(
                "DELETE FROM chat_messages WHERE id NOT IN (SELECT id FROM chat_messages ORDER BY created_at DESC, id DESC LIMIT ?)",
                arrayOf(MAX_CHAT_MESSAGES)
            )
            inserted != -1L
        } catch (_: Exception) { false }
    }

    @Synchronized
    fun recentChatMessages(limit: Int = 60): List<ChatMessage> {
        val messages = mutableListOf<ChatMessage>()
        readableDatabase.rawQuery(
            "SELECT role, content, created_at FROM chat_messages ORDER BY created_at DESC, id DESC LIMIT ?",
            arrayOf(limit.coerceIn(1, MAX_CHAT_MESSAGES).toString())
        ).use { cursor ->
            while (cursor.moveToNext()) {
                messages += ChatMessage(cursor.getString(0), cursor.getString(1), cursor.getLong(2))
            }
        }
        return messages.asReversed()
    }

    companion object {
        private const val MAX_FIELD_LENGTH = 1000
        private const val MAX_HISTORY = 500
        private const val MAX_CHAT_LENGTH = 5000
        private const val MAX_CHAT_MESSAGES = 300
    }
}

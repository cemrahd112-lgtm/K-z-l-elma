package com.kizilelma.mobile.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.WindowManager
import android.util.DisplayMetrics
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.kizilelma.mobile.commands.CommandParser
import com.kizilelma.mobile.commands.ParsedCommand

class KizilAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: KizilAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    @Volatile private var lastWindowPackage: String? = null
    @Volatile private var lastWindowChangeAt: Long = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        // Keep only lightweight state; never retain AccessibilityEvent/Node objects.
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            lastWindowPackage = event.packageName?.toString()
            lastWindowChangeAt = System.currentTimeMillis()
        }
    }
    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun execute(command: ParsedCommand): Boolean {
        return when (command.type) {
            CommandParser.Type.TAP_CENTER -> dispatchPoint(0.5f, 0.5f)
            CommandParser.Type.SWIPE_UP, CommandParser.Type.SWIPE_DOWN ->
                dispatchSwipe(command.x, command.y, command.x2, command.y2, command.durationMs)
            CommandParser.Type.CLICK_TEXT -> clickVisibleText(command.argument)
            CommandParser.Type.GO_HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
            CommandParser.Type.GO_BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
            else -> false
        }
    }

    private fun clickVisibleText(target: String): Boolean {
        val normalizedTarget = target.trim()
        if (normalizedTarget.isBlank()) return false
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(normalizedTarget)
        for (node in nodes) {
            var candidate: AccessibilityNodeInfo? = node
            var depth = 0
            try {
                while (candidate != null && depth < 12) {
                    val current = candidate
                    val clickable = current.isClickable && current.isEnabled
                    if (clickable && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        current.recycle()
                        candidate = null
                        return true
                    }
                    val parent = current.parent
                    current.recycle()
                    candidate = parent
                    depth++
                }
            } finally {
                try { candidate?.recycle() } catch (_: Exception) { }
            }
        }
        return false
    }

    private fun dispatchPoint(nx: Float, ny: Float): Boolean {
        val (width, height) = screenSize()
        if (width <= 0 || height <= 0) return false
        val safeX = nx.coerceIn(0f, 1f)
        val safeY = ny.coerceIn(0f, 1f)
        val path = Path().apply { moveTo((width * safeX).coerceIn(0f, (width - 1).toFloat()), (height * safeY).coerceIn(0f, (height - 1).toFloat())) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    private fun dispatchSwipe(x: Float, y: Float, x2: Float, y2: Float, duration: Long): Boolean {
        val (width, height) = screenSize()
        if (width <= 0 || height <= 0) return false
        fun px(value: Float, bound: Int) = (value.coerceIn(0f, 1f) * bound).coerceIn(0f, (bound - 1).toFloat())
        val path = Path().apply {
            moveTo(px(x, width), px(y, height))
            lineTo(px(x2, width), px(y2, height))
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration.coerceIn(150, 1200)))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val metrics = DisplayMetrics()
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = manager.currentWindowMetrics.bounds
            return bounds.width().coerceAtLeast(1) to bounds.height().coerceAtLeast(1)
        }
        manager.defaultDisplay.getRealMetrics(metrics)
        return metrics.widthPixels.coerceAtLeast(1) to metrics.heightPixels.coerceAtLeast(1)
    }
}

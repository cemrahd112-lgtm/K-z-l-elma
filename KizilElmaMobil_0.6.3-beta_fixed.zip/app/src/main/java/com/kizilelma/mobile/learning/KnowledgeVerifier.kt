package com.kizilelma.mobile.learning

import java.net.URI

/**
 * Evidence classification for learning records.
 * This is deliberately NOT a web fact-checker: it never claims that an external claim
 * is true merely because URLs exist or a user repeats it.
 */
enum class KnowledgeStatus {
    UNVERIFIED,
    USER_CONFIRMED,
    DEVICE_OBSERVED,
    SOURCE_LINKS_ONLY,
    CONFLICTED
}

data class VerificationResult(
    val status: KnowledgeStatus,
    val confidence: Int,
    val reason: String,
    /** May be supplied to the model as scoped context, not as an objective external fact. */
    val usableAsContext: Boolean,
    /** Always false until a real source retrieval + content comparison engine exists. */
    val usableAsExternalFact: Boolean
)

object KnowledgeVerifier {
    fun assess(
        userConfirmed: Boolean = false,
        deviceObserved: Boolean = false,
        sourceUrls: List<String> = emptyList(),
        conflictDetected: Boolean = false
    ): VerificationResult {
        if (conflictDetected) return result(
            KnowledgeStatus.CONFLICTED, 0,
            "Çelişkili kayıt bulundu; doğrulanana kadar kullanılmayacak.", false
        )

        // A direct device observation is valid only for the observed device state/time.
        if (deviceObserved) return result(
            KnowledgeStatus.DEVICE_OBSERVED, 90,
            "Cihaz gözlemi. Yalnızca gözlemin yapıldığı cihaz ve zaman kapsamı içinde bağlam olarak kullanılabilir.", true
        )

        // User confirmation establishes a user preference/correction, not an external fact.
        if (userConfirmed) return result(
            KnowledgeStatus.USER_CONFIRMED, 85,
            "Kullanıcı tarafından doğrulandı. Kullanıcı tercihi veya kullanıcıya ait bilgi olarak kullanılabilir; genel gerçek sayılmaz.", true
        )

        val validUrls = sourceUrls.mapNotNull(::normalizeHttpUrl).distinct()
        if (validUrls.isNotEmpty()) return result(
            KnowledgeStatus.SOURCE_LINKS_ONLY, 20,
            "Kaynak bağlantısı kaydedildi ancak sayfa içeriği okunup iddia ile karşılaştırılmadı. Doğrulanmış bilgi değildir.", false
        )

        return result(
            KnowledgeStatus.UNVERIFIED, 0,
            "Yeterli kanıt yok. Kesin bilgi veya kalıcı gerçek olarak kullanılmayacak.", false
        )
    }

    /** Accept only absolute HTTP(S) URLs with a host; reject malformed or deceptive schemes. */
    fun normalizeHttpUrl(raw: String): String? = try {
        val uri = URI(raw.trim()).normalize()
        val scheme = uri.scheme?.lowercase()
        val host = uri.host
        if ((scheme == "https" || scheme == "http") && !host.isNullOrBlank() && uri.userInfo == null) {
            uri.toASCIIString()
        } else null
    } catch (_: Exception) {
        null
    }

    private fun result(
        status: KnowledgeStatus,
        confidence: Int,
        reason: String,
        usableAsContext: Boolean
    ) = VerificationResult(
        status = status,
        confidence = confidence,
        reason = reason,
        usableAsContext = usableAsContext,
        usableAsExternalFact = false
    )
}

package com.kizilelma.mobile

import com.kizilelma.mobile.commands.CommandParser
import org.junit.Assert.assertEquals
import org.junit.Test

class CommandParserTest {
    @Test fun stopCommandIsRecognized() {
        assertEquals(CommandParser.Type.STOP, CommandParser.parse("acil durdur").type)
    }
    @Test fun swipeDownIsRecognized() {
        assertEquals(CommandParser.Type.SWIPE_DOWN, CommandParser.parse("aşağı kaydır").type)
    }
    @Test fun appOpenIsRecognized() {
        val parsed = CommandParser.parse("whatsapp aç")
        assertEquals(CommandParser.Type.OPEN_APP, parsed.type)
        assertEquals("whatsapp", parsed.argument)
    }
    @Test fun speechPunctuationDoesNotBreakStopCommand() {
        assertEquals(CommandParser.Type.STOP, CommandParser.parse("Durdur!").type)
    }
    @Test fun homeCommandIsRecognized() {
        assertEquals(CommandParser.Type.GO_HOME, CommandParser.parse("ana sayfaya dön").type)
    }
    @Test fun emptyInputDoesNotCreateAction() {
        assertEquals(CommandParser.Type.UNKNOWN, CommandParser.parse("   ").type)
    }
    @Test fun swipeUpIsRecognized() {
        assertEquals(CommandParser.Type.SWIPE_UP, CommandParser.parse("Yukarı kaydır!").type)
    }
    @Test fun readScreenIsRecognized() {
        assertEquals(CommandParser.Type.READ_SCREEN, CommandParser.parse("Ekranda ne var?").type)
    }
    @Test fun backCommandIsRecognized() {
        assertEquals(CommandParser.Type.GO_BACK, CommandParser.parse("geri dön").type)
    }
    @Test fun textClickIsRecognized() {
        val parsed = CommandParser.parse("ekrandaki Ayarlar yazısına tıkla")
        assertEquals(CommandParser.Type.CLICK_TEXT, parsed.type)
        assertEquals("ayarlar", parsed.argument)
    }
    @Test fun stopCommandWithTrailingWhitespaceAndPunctuationIsRecognized() {
        assertEquals(CommandParser.Type.STOP, CommandParser.parse("  Lütfen durdur!!!  ").type)
    }
    @Test fun screenReadPhraseVariantIsRecognized() {
        assertEquals(CommandParser.Type.READ_SCREEN, CommandParser.parse("Ekrandakileri oku lütfen").type)
    }
    @Test fun politeStopCommandIsRecognized() {
        assertEquals(CommandParser.Type.STOP, CommandParser.parse("Lütfen durdur!!!").type)
    }
    @Test fun politeReadScreenCommandIsRecognized() {
        assertEquals(CommandParser.Type.READ_SCREEN, CommandParser.parse("Ekrandakileri oku lütfen").type)
    }
    @Test fun blankClickTargetDoesNotCreateClickCommand() {
        assertEquals(CommandParser.Type.UNKNOWN, CommandParser.parse("tıkla").type)
    }
}

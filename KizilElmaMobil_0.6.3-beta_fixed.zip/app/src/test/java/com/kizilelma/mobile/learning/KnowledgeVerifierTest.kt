package com.kizilelma.mobile.learning

import org.junit.Assert.*
import org.junit.Test

class KnowledgeVerifierTest {
    @Test fun unsupportedClaimIsNotTrusted() {
        val result = KnowledgeVerifier.assess()
        assertEquals(KnowledgeStatus.UNVERIFIED, result.status)
        assertFalse(result.usableAsContext)
        assertFalse(result.usableAsExternalFact)
    }

    @Test fun userCorrectionIsContextButNeverAnExternalFact() {
        val result = KnowledgeVerifier.assess(userConfirmed = true)
        assertEquals(KnowledgeStatus.USER_CONFIRMED, result.status)
        assertTrue(result.usableAsContext)
        assertFalse(result.usableAsExternalFact)
    }

    @Test fun deviceObservationIsScopeLimitedContext() {
        val result = KnowledgeVerifier.assess(deviceObserved = true)
        assertEquals(KnowledgeStatus.DEVICE_OBSERVED, result.status)
        assertTrue(result.usableAsContext)
        assertFalse(result.usableAsExternalFact)
    }

    @Test fun conflictingEvidenceIsNeverTrusted() {
        val result = KnowledgeVerifier.assess(userConfirmed = true, conflictDetected = true)
        assertEquals(KnowledgeStatus.CONFLICTED, result.status)
        assertFalse(result.usableAsContext)
        assertFalse(result.usableAsExternalFact)
    }

    @Test fun sourceLinksAloneNeverProveClaim() {
        val result = KnowledgeVerifier.assess(sourceUrls = listOf("https://one.example", "https://two.example"))
        assertEquals(KnowledgeStatus.SOURCE_LINKS_ONLY, result.status)
        assertFalse(result.usableAsContext)
        assertFalse(result.usableAsExternalFact)
    }

    @Test fun malformedAndNonHttpLinksAreRejected() {
        assertNull(KnowledgeVerifier.normalizeHttpUrl("javascript:alert(1)"))
        assertNull(KnowledgeVerifier.normalizeHttpUrl("https:///missing-host"))
        assertEquals("https://example.com/path", KnowledgeVerifier.normalizeHttpUrl("https://example.com/path"))
    }
}

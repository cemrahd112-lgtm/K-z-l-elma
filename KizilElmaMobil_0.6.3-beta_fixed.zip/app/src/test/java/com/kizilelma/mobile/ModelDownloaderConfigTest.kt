package com.kizilelma.mobile

import com.kizilelma.mobile.assistant.ModelDownloader
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelDownloaderConfigTest {
    @Test
    fun modelIntegrityAndRevisionArePinnedTogether() {
        assertEquals(64, ModelDownloader.EXPECTED_SHA256.length)
        assertTrue(ModelDownloader.EXPECTED_SHA256.matches(Regex("[0-9a-f]{64}")))
        assertEquals(613722264L, ModelDownloader.EXPECTED_SIZE)
        assertTrue(ModelDownloader.MODEL_URL.contains("/resolve/${ModelDownloader.MODEL_REVISION}/"))
        assertFalse(ModelDownloader.MODEL_URL.contains("/resolve/main/"))
    }
}

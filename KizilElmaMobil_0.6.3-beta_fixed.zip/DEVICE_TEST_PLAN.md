# Gerçek cihaz doğrulama planı

Bu senaryolar henüz başarılı test edilmiş değildir. Sonuçlar cihaz modeli, Android sürümü, uygulama sürümü ve test tarihiyle kaydedilmelidir.

## Ön koşullar
- Android Gradle derlemesi ve APK kurulumu başarılı olmalı.
- Model indirme, SHA-256 doğrulaması ve model başlatma ayrı ayrı kontrol edilmeli.
- Android sürümü, cihaz modeli, RAM ve pil durumu test kaydına eklenmeli.

## Senaryolar

| ID | Senaryo | Beklenen sonuç |
|---|---|---|
| OCR-01 | Kullanıcı MediaProjection izni verir; ekranda büyük ve okunaklı metin bulunan bir sayfa açılır. | OCR metni doğru çıkarır; ekran yakalama bitince kaynaklar serbest bırakılır. |
| OCR-02 | Kullanıcı ekran yakalama iznini reddeder veya oturumu durdurur. | Uygulama yakalama yapmaz; hata/izin durumu açıkça gösterilir; çökme olmaz. |
| ACC-01 | Kullanıcı Accessibility Service'i Ayarlar'dan etkinleştirir; test uygulamasında görünen bir metne dokunma komutu verir. | Yalnızca hedeflenen görünür öğe tıklanır; sonuç gerçekleştiği doğrulanmadan başarı bildirilmez. |
| ACC-02 | Kullanıcı Android Ayarlar içinde geri ve kaydırma komutlarını dener. | İşlem desteklenen ekranda yapılır; desteklenmeyen durumda yanlış başarı mesajı verilmez. |
| VOICE-01 | Mikrofon izni verilir ve Türkçe kısa komut söylenir. | Tanınan metin arayüze gelir; izin reddedilirse yazılı sohbet çalışmaya devam eder. |
| VOICE-02 | Cihazda çevrimdışı konuşma tanıma kapalı veya kullanılamaz durumdadır. | Uygulama gerçek tanıma modunu belirtir; çevrimdışı çalıştığını iddia etmez. |
| MODEL-01 | İlk model indirmesi tamamlanır, ardından model yüklenir. | Dosya boyutu ve SHA-256 doğrulanır; model açılış ve ilk yanıt süresi ölçülür. |
| MEMORY-01 | Uygulama kapatılıp yeniden açılır. | Son 300 sohbet mesajı sınırı içinde geçmiş geri yüklenir; tercihler cihazda korunur. |

## Test raporu alanları
- Cihaz / Android sürümü
- APK sürümü ve SHA-256
- Senaryo ID
- Adımlar ve beklenen sonuç
- Gerçek sonuç: PASS / FAIL / BLOCKED
- Hata günlüğü ve ekran görüntüsü (kişisel veri temizlenmiş)
- Tekrar üretme adımları

# Kızıl Elma Mobil 0.6.2-beta

## This revision
- Added a persistent chat transcript with separate USER, ASSISTANT, and SYSTEM messages.
- Added a bounded chat history table (up to 300 messages, up to 5,000 characters each) and a database migration from version 2 to 3.
- Restores recent chat transcript after app restart and supplies a short recent conversation window to the local model after restart.
- Moved microphone permission request from app startup to the moment the user selects voice input; denial leaves text commands available.
- Records command outcomes in the visible transcript and uses precise language when Android accepted an action request but the final screen outcome was not verified.
- Added launcher-intent package visibility and exact app-label matching so supported installed apps can be opened by their displayed name without requesting broad package visibility.
- Revalidates the model file's expected size and SHA-256 at the inference-engine boundary before loading.
- Reworked screen-frame conversion to copy each actual pixel row and reject truncated image buffers rather than silently padding missing bytes.
- Updated application version to 0.6.2-beta (versionCode 15).

## Not added in this revision
- No independent web retrieval/content comparison fact-checker. Source links alone remain unverified.
- No automatic skill authoring, approval, or execution.
- No on-device or background model fine-tuning / weight replacement.

# Kızıl Elma Mobil 0.6.3-beta — Build Status

## Feature status in source code

| Feature | 0.6.3-beta status | Evidence / limitation |
|---|---|---|
| User preferences and explicit corrections | Implemented in source | SQLite `LearningStore`; explicit correction path only |
| Successful/failed/unknown command experiences | Implemented in source | SQLite `experiences` records; does not prove automatic learning from all messages |
| Chat history restore | Implemented in source | SQLite `chat_messages`, capped at 300 messages |
| Conflicting knowledge exclusion | Implemented in classification/context policy | Conflict status is not included in trusted context; this is not independent fact-checking |
| URL syntax validation | Implemented in source | HTTP(S) URL normalization only; no page fetch |
| Independent web content verification | Not implemented | No retrieval, source-quality scoring, or claim-to-source comparison |
| Skill candidate storage | Implemented in source | Candidates can be recorded; no approval UI or skill execution engine |
| Automatic skill generation/approval | Not implemented | Must remain user-reviewed |
| Model fine-tuning / weight updates | Not implemented | Separate training and release pipeline required |
| Supabase / Firebase / Firecrawl app integration | Not implemented | ChatGPT plugins are not automatically embedded in the Android app |
| Speech recognition / TTS | Integration code present | Android build and real-device behavior not verified |
| Accessibility actions | Service code present | App-by-app and Android-version testing pending |
| Screen capture / OCR | Service code present | MediaProjection lifecycle and OCR need device testing |

## Validation actually performed in this environment
- `KnowledgeVerifier.kt` and `CommandParser.kt` compiled with the installed Kotlin 1.9.0 compiler.
- A syntax-diagnostic scan of the Android Kotlin source reported no parser-level syntax errors; Android/library type resolution was unavailable.
- 10 direct smoke assertions passed for knowledge classification, URL rejection, and command parsing.
- Android manifest and all resource XML files parsed successfully.
- SQLite schema/migration statements checked with SQLite syntax execution.
- `build-debug.sh` passed shell syntax validation.
- ZIP integrity and archive root structure checked.
- Build configuration versions checked against published compatibility information: AGP 8.7 requires Gradle 8.9; Kotlin Gradle Plugin 2.4.21 supports AGP 8.5.2–9.3.1 and Gradle 7.6.3–9.7.0.

## Not performed / limitations
- Full Android Gradle build was not performed: this environment has no Android SDK or platform `android.jar`.
- Gradle Wrapper files were added (`gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`, `gradle-wrapper.properties` targeting Gradle 8.9). The wrapper has not been executed here.
- Android JUnit tests were not run; the 10 smoke assertions are not a substitute for the Android Gradle test task.
- APK generation and real-device testing were not performed.
- LiteRT-LM API linkage and native runtime loading have not been verified by an Android build/device run.
- The 0.6B model is downloaded on first use (about 586 MiB / 614 MB). Runtime memory, latency, and thermal behavior on the target phone remain unmeasured.
- No independent web source retrieval/content comparison fact-checker exists yet. The app correctly refuses to treat a URL alone as proof.
- Automatic skill generation/approval/execution and model fine-tuning/weight replacement remain unimplemented.

## Build requirements
- JDK 17.
- Android SDK Platform 35 and Build Tools 35.0.0.
- Android Gradle Plugin 8.7.3 with Gradle 8.9.
- Kotlin Gradle Plugin 2.4.21.
- Gradle Wrapper is included. On Linux/macOS: `chmod +x gradlew && ./gradlew :app:assembleDebug`
- On Windows: `gradlew.bat :app:assembleDebug`
- Unit tests: `./gradlew :app:testDebugUnitTest`

This archive is Android source code, not an APK. Do not describe it as device-tested or production-ready until the missing build and device checks pass.


## 0.6.3-beta model sabitleme düzeltmesi

- Model URL'si Hugging Face revision `e6687177e00897731e7716267eebd4eba0dde7c2` ile sabitlendi; `main` kullanılmıyor.
- Beklenen boyut: `613722264` bayt.
- Beklenen SHA-256: `c5f39b4191926786c3e6668b62af4d6eb15248dfc7a5348252a9b406f33f2108` (64 hexadecimal karakter).
- Bu değerler Hugging Face dosya kaydı/revision sayfasıyla karşılaştırıldı; modelin tamamı bu ortamda indirilip hash'i yeniden hesaplanmadı.
- Android derlemesi ve cihaz testi hâlâ yapılmadı.

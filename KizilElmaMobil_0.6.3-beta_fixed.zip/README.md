# Kızıl Elma Mobil 0.6.3-beta

Kızıl Elma Mobil, Android üzerinde çalışan yerel bir dil modeliyle sohbet etmeyi; konuşma geçmişini, kullanıcı tercihlerini ve komut deneyimlerini cihazda saklamayı; izin verildiğinde Android erişilebilirlik ve ekran yakalama servisleriyle telefon arayüzünde işlem yapmayı hedefleyen kişisel asistan projesidir. Bu depo bir **Android kaynak kodu** paketidir; APK değildir.

## 0.6.3-beta kapsamı

### Kaynak kodda bulunanlar
- Kotlin tabanlı Android uygulaması ve sohbet arayüzü.
- Qwen3-0.6B LiteRT-LM modelini ilk kullanımda indirme, dosya boyutu ve SHA-256 kontrolü.
- LiteRT-LM üzerinden yerel model motoru entegrasyonu (Android derlemesi ve cihaz çalıştırması henüz doğrulanmadı).
- SQLite ile komut geçmişi, konuşma geçmişi, kullanıcı tercihleri, bilgi sınıflandırma kayıtları ve deneyim kayıtları.
- Son 300 sohbet mesajının saklanması ve yeniden açılışta sınırlı konuşma bağlamının geri yüklenmesi.
- Kullanıcı düzeltmesi, cihaz gözlemi ve kaynak URL'si ayrımını yapan kanıt sınıflandırması; çelişki işaretlenmiş kayıtların güvenilir bağlama alınmaması.
- Android SpeechRecognizer / TextToSpeech entegrasyon kodu.
- Accessibility Service üzerinden arayüz etkileşimi için servis kodu.
- MediaProjection ve ML Kit OCR ile ekran yakalama/metin tanıma kodu.

### Kodda olmayan veya henüz doğrulanmayanlar
- Supabase, Firebase veya Firecrawl uygulama entegrasyonu.
- Web sayfası içeriğini çekip iddialarla semantik olarak karşılaştıran bağımsız doğrulama hattı.
- Otomatik beceri çıkarımı, kullanıcı onay ekranı ve güvenli beceri çalıştırma motoru.
- Model ağırlıklarını cihazda güncelleme veya uygulama içinden fine-tuning.
- Başarılı Android Gradle derlemesi, APK üretimi ve gerçek cihaz testleri.

Ayrıntılı durumlar için `BUILD_STATUS.md`, `PRIVACY_AND_DATA_FLOW.md` ve `DEVICE_TEST_PLAN.md` dosyalarına bakın.

## Yerel model
- Model: Qwen3-0.6B LiteRT-LM (`Qwen3-0.6B.litertlm`).
- Dosya boyutu: 613,722,264 bayt (yaklaşık 586 MiB / 614 MB).
- Hugging Face revision: `e6687177e00897731e7716267eebd4eba0dde7c2`.
- SHA-256: `c5f39b4191926786c3e6668b62af4d6eb15248dfc7a5348252a9b406f33f2108`.
- Model ilk kullanımda indirilir; ağırlıklar APK içine gömülmez.
- CPU çalışma yolu yapılandırılmıştır; hedef cihazda hız, bellek ve ısıl davranış ölçülmemiştir.

## Gizlilik varsayılanı
0.6.3-beta'da sohbet, tercih, komut ve öğrenme kayıtları SQLite ile cihazda tutulur. Bu sürümde Supabase/Firebase/Firecrawl veri gönderimi kodlanmış değildir. Gelecek bulut entegrasyonlarında varsayılan yaklaşım açık kullanıcı onayı, veri minimizasyonu ve gönderim öncesi görünür bilgilendirme olacaktır. Bu bir mimari gereksinimdir; henüz uygulama içi onay akışı olarak uygulanmış değildir. Ayrıntı: `PRIVACY_AND_DATA_FLOW.md`.

## Derleme gereksinimleri
- JDK 17
- Android SDK Platform 35 ve Build Tools 35.0.0
- Android Gradle Plugin 8.7.3, Gradle 8.9
- Kotlin Gradle Plugin 2.4.21

Gradle Wrapper eklendi (`gradlew`, `gradlew.bat`, `gradle/wrapper/`).  
İlk kullanımda:

```bash
chmod +x gradlew   # Linux / macOS
./gradlew :app:assembleDebug
./gradlew :app:testDebugUnitTest
```

Windows: `gradlew.bat :app:assembleDebug`

Android Studio'da proje kökünü açmak da yeterlidir; Studio wrapper'ı kullanır.

## Lisans ve kaynaklar
Model kartı: https://huggingface.co/litert-community/Qwen3-0.6B  
LiteRT-LM Android belgeleri: https://developers.google.com/edge/litert-lm/android

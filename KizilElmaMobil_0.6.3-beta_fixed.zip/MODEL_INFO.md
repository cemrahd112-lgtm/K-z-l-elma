# Yerel model bilgisi

- Model: Qwen3-0.6B LiteRT-LM
- Dosya: `Qwen3-0.6B.litertlm`
- İndirme boyutu: 613,722,264 bayt (yaklaşık 586 MiB / 614 MB)
- Hugging Face revision: `e6687177e00897731e7716267eebd4eba0dde7c2`
- SHA-256: `c5f39b4191926786c3e6668b62af4d6eb15248dfc7a5348252a9b406f33f2108`
- Lisans: Apache-2.0 (model kartında belirtilen)
- Runtime: LiteRT-LM Android 0.19.0 (cihazda henüz doğrulanmadı)
- Çalışma backend'i: CPU

Model uygulama tarafından ilk kullanımda indirilir. Model ağırlıkları APK'ya gömülmez. İlk indirme için internet gerekir; indirme ve SHA-256 doğrulaması tamamlandıktan sonra metin üretimi cihaz üzerinde yapılır. Modelin POCO X6 Pro üzerindeki gerçek hız ve bellek tüketimi henüz ölçülmemiştir.

Kaynaklar:
- Model kartı: https://huggingface.co/litert-community/Qwen3-0.6B
- Dosya: https://huggingface.co/litert-community/Qwen3-0.6B/resolve/e6687177e00897731e7716267eebd4eba0dde7c2/Qwen3-0.6B.litertlm
- LiteRT-LM Android API: https://developers.google.com/edge/litert-lm/android

## Runtime caution
The repository's model card lists the standard INT8 file at 586 MB. Published CPU command-line measurements on example retail devices report peak private memory footprints around 2.7 GB; these are not measurements of this app or the target phone. The target phone's available RAM, runtime memory, latency, and thermal behavior must be tested before claiming stable operation.

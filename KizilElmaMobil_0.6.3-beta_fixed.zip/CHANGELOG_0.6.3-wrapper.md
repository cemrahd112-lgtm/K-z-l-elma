# Gradle Wrapper eklentisi (0.6.3-beta üzerine)

- `gradlew` ve `gradlew.bat` eklendi (Gradle 8.9 kaynaklı resmi betikler).
- `gradle/wrapper/gradle-wrapper.properties` eklendi; dağıtım adresi `gradle-8.9-bin.zip`.
- `gradle/wrapper/gradle-wrapper.jar` eklendi.
- `build-debug.sh` ve `build-debug.bat` artık sistem `gradle` yerine `./gradlew` / `gradlew.bat` kullanıyor.
- GitHub Actions workflow (`android-build.yml`) Wrapper kullanacak şekilde güncellendi; ayrı Gradle kurulumu kaldırıldı.
- README ve BUILD_STATUS derleme bölümleri güncellendi.

## Not
Bu değişiklik yeni bir sürüm numarası yükseltmesi değildir. Model sabitlemesi ve bağımlılık tanımları 0.6.3-beta ile aynıdır. Wrapper bu ortamda çalıştırılmadı; gerçek derleme hâlâ Android SDK bulunan bir makinede yapılmalıdır.

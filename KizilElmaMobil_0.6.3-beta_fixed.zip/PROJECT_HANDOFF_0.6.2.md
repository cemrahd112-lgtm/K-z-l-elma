# Build handoff — 0.6.2-beta

This is the Android Gradle project root. Do not wrap it as an HTML app.

## Required environment
- JDK 17
- Android SDK Platform 35
- Android Build Tools 35.0.0
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin Gradle Plugin 2.4.21

## Build commands
From this directory:

```bash
gradle --version
gradle --no-daemon :app:clean :app:testDebugUnitTest :app:assembleDebug
```

Expected debug APK path after a successful build:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## First launch
1. Install the debug APK on an Android 8.0+ device.
2. Open the app. Text command input is available without granting microphone access.
3. Tap the model button. The first model download is approximately 586 MiB / 614 MB and requires internet access.
4. The model file is checked against its expected byte size and SHA-256 before loading.
5. For voice commands, grant microphone permission only when prompted after tapping the voice button.
6. For screen reading and cross-app actions, grant the relevant Android screen-capture and accessibility permissions when the user explicitly enables those functions.
7. App launch by name uses an exact visible launcher-label match; ambiguous or unmatched names are rejected rather than guessed.

## Do not treat as passed until verified
- Build and Android unit-test tasks complete successfully.
- APK installs and launches on the target phone.
- Model download, checksum validation, model initialization, and at least one Turkish prompt/reply succeed.
- Conversation history survives app restart.
- Voice, screen capture/OCR, accessibility gestures, and stop behavior are tested individually.
- Low-memory and network interruption behavior are tested.

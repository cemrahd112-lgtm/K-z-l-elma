# 0.6.1-beta değişiklikleri

- Kullanıcı düzeltmeleri işlem bütünlüğüyle kaydediliyor ve kullanıcı bağlamı olarak işaretleniyor.
- Kullanıcı onayı dış dünya gerçeği doğrulaması olarak kabul edilmiyor.
- Cihaz gözlemi yalnızca kendi kapsamı içinde kullanılabiliyor.
- Kaynak URL'leri artık `SOURCE_LINKS_ONLY` olarak sınıflandırılıyor; bağlantı tek başına kanıt değil.
- HTTP(S) adresleri URI olarak doğrulanıyor; geçersiz şemalar ve host bilgisi olmayan adresler reddediliyor.
- Eski veritabanındaki URL-temelli kayıtlar güven seviyesi düşürülerek taşınıyor.
- Aday beceriler mevcut/onaylı becerilerin üzerine yazamıyor.
- Yerel modele verilen öğrenme ve OCR verilerinin talimat olarak izlenmemesi açıkça belirtiliyor.
- Bilgi doğrulama testleri genişletildi.

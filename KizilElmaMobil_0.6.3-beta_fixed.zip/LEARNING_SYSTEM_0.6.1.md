# Learning and evidence system — 0.6.1-beta

## Implemented
- Persistent user preferences and explicit corrections. Saving a correction and its provenance record is transactional.
- User-confirmed corrections are scoped to the user's preferences/context; they are never treated as proof of an external-world claim.
- Device observations are scoped to the observed device/time and are not external facts.
- Conflicting records are blocked from trusted context.
- URL validation accepts only absolute HTTP(S) URLs with a host and rejects user-info/deceptive schemes.
- URL presence is classified as `SOURCE_LINKS_ONLY`; it is not evidence that the page was fetched, read, independent, or supportive.
- Learning context labels preferences and experiences as data, not instructions.
- Experience records retain SUCCESS/FAILURE/UNKNOWN outcomes.
- Candidate skill insertion cannot overwrite an existing skill, including an approved one.
- Database upgrade migrates the old `SOURCE_SUPPORTED` label to the more accurate `SOURCE_LINKS_ONLY` label without promoting it.

## Not implemented
- No independent internet retrieval, page parsing, source-quality evaluation, or claim-to-source semantic comparison. Therefore no external factual claim can currently reach an independently verified state.
- No automatic skill extraction, approval interface, or skill execution engine.
- No model fine-tuning, weight updates, or model replacement.
- No automatic learning from every free-form user message; only explicit correction syntax is persisted as a preference.

## Safety rule
User confirmation can establish a preference or user-specific correction, not an objective external fact. A device observation can establish only what the app observed in its scope. Source URLs alone are not proof. If evidence conflicts or is absent, the record must not be presented as a verified fact.

## 0.6.2 application integration notes
- The UI now persists USER / ASSISTANT / SYSTEM chat messages separately from command history.
- Recent conversation is restored after app restart and supplied as bounded context to the local model.
- Microphone permission is deferred until voice input is explicitly requested.
- The application still does not fetch external pages or semantically compare source contents. Do not mark external claims as verified.

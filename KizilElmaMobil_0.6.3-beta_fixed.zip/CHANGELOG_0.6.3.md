# Kızıl Elma Mobil 0.6.3-beta

- Model indirme adresi Hugging Face revision `e6687177e00897731e7716267eebd4eba0dde7c2` sürümüne sabitlendi; `main` dalına bağlılık kaldırıldı.
- Model dosyası boyutu `613722264` bayt olarak korundu.
- SHA-256 sabiti, Hugging Face dosya sayfası ve revision kaydıyla eşleşen 64 karakterlik değerle düzeltildi: `c5f39b4191926786c3e6668b62af4d6eb15248dfc7a5348252a9b406f33f2108`.
- README ve MODEL_INFO aynı revision, URL, boyut ve hash bilgileriyle güncellendi.
- Model sabitlemesini ve hash uzunluğunu kontrol eden birim testi eklendi.
- Android `versionCode` 16, `versionName` 0.6.3-beta olarak artırıldı.

## Doğrulama sınırı

Hugging Face dosya kaydı ve revision bilgisi kaynak üzerinden kontrol edildi. Bu çalışma ortamında 614 MB model dosyasının tamamı indirilip yerel SHA-256 yeniden hesaplanmadı. Android Gradle derlemesi, APK üretimi ve gerçek cihaz testi yapılmadı. Eklenen birim testi de Android/Gradle test görevi çalıştırılmadığı için henüz yürütülmüş değildir.

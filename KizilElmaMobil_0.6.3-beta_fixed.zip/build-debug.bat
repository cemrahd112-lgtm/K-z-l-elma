@echo off
setlocal
cd /d "%~dp0"

if not exist "gradlew.bat" (
  echo gradlew.bat bulunamadi. Proje kokunde Gradle Wrapper olmali.
  exit /b 2
)

if "%ANDROID_HOME%%ANDROID_SDK_ROOT%"=="" (
  echo ANDROID_HOME veya ANDROID_SDK_ROOT tanimli degil.
  exit /b 2
)

call gradlew.bat --no-daemon :app:clean :app:testDebugUnitTest :app:assembleDebug
if errorlevel 1 exit /b %errorlevel%

if exist "app\build\outputs\apk\debug\app-debug.apk" (
  echo APK hazir: app\build\outputs\apk\debug\app-debug.apk
) else (
  echo Uyari: Beklenen APK yolu bulunamadi.
  exit /b 1
)

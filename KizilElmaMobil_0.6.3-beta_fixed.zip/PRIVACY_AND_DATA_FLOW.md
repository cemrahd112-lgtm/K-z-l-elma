# Gizlilik ve veri akışı — 0.6.2-beta

## Mevcut sürümdeki gerçek durum

- Sohbet mesajları, komut geçmişi, kullanıcı tercihleri, öğrenme kayıtları ve deneyim kayıtları uygulamanın yerel SQLite veritabanlarında saklanır.
- Model dosyası ilk indirmede HTTPS üzerinden Hugging Face adresinden cihaza indirilir. Model dosyası APK içine gömülmez.
- Uygulama kaynak kodunda Supabase, Firebase veya Firecrawl istemcisi/entegrasyonu bulunmamaktadır. Bu nedenle bu servislere öğrenme veya sohbet verisi gönderildiği söylenemez.
- Android SpeechRecognizer'ın cihaz üzerinde mi yoksa ağ tabanlı sağlayıcı üzerinden mi çalışacağı cihazın servislerine ve seçilen tanıma yapılandırmasına bağlı olabilir. Bu nedenle sesin her durumda cihazdan çıkmadığı garantisi verilmez.
- Ekran yakalama, Android MediaProjection izniyle başlatılır; kullanıcı sistem onayı vermeden ekran yakalama başlamamalıdır.

## Gelecek bulut entegrasyonları için zorunlu tasarım kuralları

1. Varsayılan: sohbet, kişisel hafıza ve öğrenme kayıtları cihazda kalır.
2. Buluta aktarım yalnızca kullanıcı açıkça etkinleştirip hangi veri türünün gönderileceğini gördükten sonra yapılır.
3. Ham ekran görüntüsü, mikrofon kaydı ve özel sohbet içeriği varsayılan olarak buluta gönderilmez.
4. Mümkün olduğunda yalnızca gerekli, küçültülmüş metin/özet gönderilir; erişim anahtarları APK içine gömülmez.
5. Kullanıcı senkronizasyonu kapatabilmeli ve buluta gönderilen kayıtları silebilmelidir.
6. Ağ istekleri, amaç, hedef servis ve gönderilen veri türü uygulama içinde açıklanmalıdır.

Bu bölümdeki altı kural gelecek sürümler için mimari gereksinimdir; henüz uygulanmış bir izin/onay arayüzü olarak değerlendirilmemelidir. KVKK uyumluluğu yalnızca bu notla sağlanmış sayılmaz; gerçek veri envanteri, hukuki dayanak, saklama süresi, silme ve güvenlik süreçleri ayrıca tasarlanmalıdır.

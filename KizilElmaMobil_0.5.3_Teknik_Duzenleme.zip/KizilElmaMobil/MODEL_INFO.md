# Yerel model bilgisi

- Model: Qwen3-0.6B LiteRT-LM
- Dosya: `Qwen3-0.6B.litertlm`
- İndirme boyutu: 613,722,264 bayt (yaklaşık 586 MiB / 614 MB)
- SHA-256: `c5f39b419192678c3e6668b62af4d6eb15248dfc7a5348252a9b406f33f2108`
- Lisans: Apache-2.0 (model kartında belirtilen)
- Runtime: LiteRT-LM Android 0.19.0
- Çalışma backend'i: CPU

Model uygulama tarafından ilk kullanımda indirilir. Model ağırlıkları APK'ya gömülmez. İlk indirme için internet gerekir; indirme ve SHA-256 doğrulaması tamamlandıktan sonra metin üretimi cihaz üzerinde yapılır. Modelin POCO X6 Pro üzerindeki gerçek hız ve bellek tüketimi henüz ölçülmemiştir.

Kaynaklar:
- Model kartı: https://huggingface.co/litert-community/Qwen3-0.6B
- Dosya: https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B.litertlm
- LiteRT-LM Android API: https://developers.google.com/edge/litert-lm/android

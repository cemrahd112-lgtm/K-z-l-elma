@echo off
setlocal
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle 8.9 gerekli. Android Studio kurulumundaki Gradle dagitimini PATH'e ekleyin.
  exit /b 2
)
if "%ANDROID_HOME%%ANDROID_SDK_ROOT%"=="" (
  echo ANDROID_HOME veya ANDROID_SDK_ROOT tanimli degil.
  exit /b 2
)
gradle --no-daemon :app:clean :app:assembleDebug :app:testDebugUnitTest
if errorlevel 1 exit /b %errorlevel%
echo APK hazir: app\build\outputs\apk\debug\app-debug.apk

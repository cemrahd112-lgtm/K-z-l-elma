#!/usr/bin/env bash
set -euo pipefail

if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle 8.9 gerekli. Android Studio kurulumunuzdaki Gradle dağıtımını PATH'e ekleyin." >&2
  exit 2
fi
if [[ -z "${ANDROID_HOME:-}${ANDROID_SDK_ROOT:-}" ]]; then
  echo "ANDROID_HOME veya ANDROID_SDK_ROOT tanımlı değil." >&2
  exit 2
fi

gradle --no-daemon :app:clean :app:assembleDebug :app:testDebugUnitTest
printf '\nAPK hazır: %s\n' "$(pwd)/app/build/outputs/apk/debug/app-debug.apk"

# KIZIL ELMA MOBİL — Android kaynak proje 0.5.2-beta

Bu sürüm, önceki oturumda bulunan eksik kaynak dosyaları yeniden düzenleyerek gerçek ekran OCR hattı, temel sesli komut girişi, erişilebilirlik hareketleri ve SQLite komut geçmişi ekler. Önceki v0.2 kaynak arşivi bulunamadığından bu paket onun birebir devamı değildir.

## Dahil edilen işlevler
- Kotlin Android uygulaması ve ViewBinding arayüzü
- MediaProjection kullanıcı onayıyla ekran yakalama servisi
- VirtualDisplay + ImageReader üzerinden kare alma
- ML Kit Latin OCR ile ekrandaki yazıları cihaz üzerinde okuma
- OCR sonucunu uygulama ekranına aktarma
- Android SpeechRecognizer üzerinden Türkçe sesli komut girişi
- Android TextToSpeech ile Türkçe sesli geri bildirim (cihazdaki Türkçe TTS motoruna bağlı)
- LiteRT-LM tabanlı yerel Qwen3-0.6B metin modeli; uygulama içinden model indirme, SHA-256 doğrulama, CPU inference ve çok turlu sohbet
- Komut ayrıştırma: durdur, yukarı/aşağı kaydır, ana ekran, geri, ekrandaki metne tıkla, ekranı oku, tanımlı uygulamaları aç
- AccessibilityService ile metin düğümü bulma ve tıklama; temel jestler
- SQLite komut geçmişi
- Acil durdurma ve komut ayrıştırıcı birim testleri

## Yerel yapay zekâ modeli
Uygulama LiteRT-LM 0.19.0 ile Qwen3-0.6B modelini cihaz üzerinde CPU'da çalıştıracak şekilde bağlanmıştır. İlk kullanımda uygulamadaki model düğmesi, yaklaşık 614 MB boyutundaki modeli Hugging Face üzerinden indirir; SHA-256 değeri doğrulanmadan dosyayı etkinleştirmez. Model APK içine gömülmez. İlk indirme için internet ve yaklaşık 1 GB boş alan gerekir; indirme tamamlandıktan sonra metin üretimi yerel yapılır. Modelin cihazdaki gerçek hızı ve bellek kullanımı POCO X6 Pro üzerinde henüz ölçülmemiştir.

## Bilinen sınırlar
- OCR bu sürümde Latin alfabesi modelini kullanır; Türkçe karakter tanıma başarımı cihaz/ekran kalitesine göre değişebilir.
- SpeechRecognizer'ın çevrimdışı çalışması Android sürümüne ve cihazdaki konuşma tanıma hizmetine bağlıdır. Çevrimdışı tercih işareti garanti değildir.
- Uygulama açma komutları yalnızca kodda tanımlı kısayolları kapsar: Ayarlar, Kamera, Telefon, Mesajlar, tarayıcı, YouTube, WhatsApp ve Haritalar.
- Erişilebilirlik servisi kullanıcı tarafından Android Ayarları'ndan ayrıca etkinleştirilmelidir.
- OCR metni gösterilir; her metnin otomatik ve güvenilir bir eylem planına çevrilmesi henüz yoktur.
- Ödeme, mesaj gönderme, satın alma, silme gibi hassas işlemler otomatikleştirilmez.

## Derleme ortamı
Android Studio, JDK 17, Android SDK Platform 35, Android Gradle Plugin 8.7.3, Kotlin Gradle Plugin 2.4.21 ve Gradle 8.9 veya uyumlu dağıtım gerekir. Gradle wrapper dosyaları arşive dahil değildir. İlk Gradle Sync sırasında ML Kit bağımlılığı internetten indirilir.

## İlk cihaz testi
1. Projeyi Android Studio'da açıp Gradle Sync yapın.
2. Uygulamayı telefona kurun.
3. Mikrofon ve bildirim izinlerini verin.
4. Android Erişilebilirlik ayarlarından KIZIL ELMA MOBİL servisini etkinleştirin.
5. “Ekran analizini başlat” düğmesine basıp Android ekran paylaşımı onayını verin.
6. Ekran metninin OCR alanında belirmesini kontrol edin.
7. “Yerel yapay zekâyı indir / yükle” düğmesine basın. Yaklaşık 614 MB model indirilecek ve SHA-256 doğrulaması yapılacaktır. Ardından modelin yüklenmesini bekleyin.
8. Serbest metin sorusunu girin veya sesle sorun; model yanıtının cihaz üzerinde üretildiğini kontrol edin.
9. “aşağı kaydır”, “ekrandaki Ayarlar yazısına tıkla”, “ekranı oku” komutlarını deneyin.
10. “ACİL DURDUR” ile ekran yakalama oturumunu kapatın.

## Güvenlik ve gizlilik
- Ekran yakalama her oturumda Android sistem onayı ister.
- Ekran kareleri OCR için cihaz üzerinde işlenir; bu kod OCR metnini sunucuya göndermez.
- Erişilebilirlik izni güçlü bir izindir. Yalnızca güvendiğiniz kendi derlemenizde etkinleştirin.
- İlk testleri hassas bilgi içermeyen ekranlarda yapın.


## Derleme ve APK alma

`.github/workflows/android-build.yml` iş akışı, Android kaynak kodları depo köküne yüklendiğinde projeyi doğrudan derler. `main` veya `master` dalına ilgili kaynak değişiklikleri gönderildiğinde otomatik çalışır; GitHub Actions içinden elle de başlatılabilir. Başarılı çalışmada `KizilElmaMobil-debug-apk` adlı artifact oluşturulur.

İş akışı JDK 17, Gradle 8.9 ve Android SDK 35 kullanır; önce `:app:testDebugUnitTest`, ardından `:app:assembleDebug` görevlerini çalıştırır. APK yolu `app/build/outputs/apk/debug/app-debug.apk` olur. Bu çıktı test amaçlı debug APK'dır; mağaza dağıtımı için imzalı release APK değildir.

## Derleme doğrulaması
Bu çalışma ortamında Android SDK ve Gradle bulunmadığından, ayrıca dış ağ DNS erişimi kapalı olduğundan APK burada üretilemedi. Bu nedenle derlenmiş APK veya gerçek cihaz testi yapılmış olduğu iddia edilmez. Yapılan statik kontroller ve kalan doğrulamalar `BUILD_STATUS.md` dosyasında listelenmiştir.

# Derleme ve teknik inceleme durumu — 0.5.2-beta

## Düzenlenenler
- GitHub Actions iş akışı, kaynak ZIP arşivini aramak yerine depo kökündeki Android projesini doğrudan derleyecek şekilde düzeltildi.
- İş akışı `main` ve `master` dallarındaki Android kaynak/değişiklikleri için tetiklenir; elle çalıştırma da desteklenir.
- Testler derlemeden önce çalıştırılır ve yalnızca başarılı derlemede debug APK artifact'i yüklenir.

## Kod incelemesinde belirlenen önemli eksikler
- Yerel LLM şu anda yalnızca `UNKNOWN` komutlarda metin yanıtı üretir; model çıktısı yapılandırılmış bir eylem planına dönüştürülüp izinli eylemlerle eşleştirilmez. Bu nedenle genel sohbet ile telefon kontrolü henüz bütünleşik değildir.
- OCR yalnızca son metni arayüze taşır. OCR sonucu değiştiğinde modelin bağlamı otomatik güncellenmez; ekranı yorumlama ve eylem önerme döngüsü yoktur.
- `READ_SCREEN` komutu yalnızca mevcut OCR metnini okur; ekran yakalama etkin değilse boş sonuç verir.
- Uygulama açma yalnızca kodda sabitlenmiş paket/intent eşlemelerini kapsar.
- LiteRT-LM API ve model dosyası eşleşmesi gerçek Gradle derlemesi ve cihazda model başlatma testiyle doğrulanmadı.
- Modelin indirme URL'si, beklenen dosya boyutu ve SHA-256 değeri bu ortamda uzaktan doğrulanamadı.
- MediaProjection, OCR, ses tanıma, TTS ve erişilebilirlik akışları gerçek Android cihazda henüz test edilmedi.

## Doğrulama sınırı
Bu ortamda Android SDK ve Gradle bulunmadığından APK üretimi ve Gradle birim testleri çalıştırılamadı. Bu nedenle yapılan değişiklikler kaynak/iş akışı düzeyindedir; başarılı derleme veya çalışan APK iddiası değildir.

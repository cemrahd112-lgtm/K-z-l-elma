package com.kizilelma.mobile

import com.kizilelma.mobile.commands.CommandParser
import org.junit.Assert.assertEquals
import org.junit.Test

class CommandParserTest {
    @Test fun stopCommandIsRecognized() {
        assertEquals(CommandParser.Type.STOP, CommandParser.parse("acil durdur").type)
    }
    @Test fun swipeDownIsRecognized() {
        assertEquals(CommandParser.Type.SWIPE_DOWN, CommandParser.parse("aşağı kaydır").type)
    }
    @Test fun appOpenIsRecognized() {
        val parsed = CommandParser.parse("whatsapp aç")
        assertEquals(CommandParser.Type.OPEN_APP, parsed.type)
        assertEquals("whatsapp", parsed.argument)
    }
    @Test fun textClickIsRecognized() {
        val parsed = CommandParser.parse("ekrandaki Ayarlar yazısına tıkla")
        assertEquals(CommandParser.Type.CLICK_TEXT, parsed.type)
        assertEquals("ayarlar", parsed.argument)
    }
}

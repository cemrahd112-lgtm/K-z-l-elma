package com.kizilelma.mobile.commands

import java.util.Locale

data class ParsedCommand(
    val type: CommandParser.Type,
    val description: String,
    val argument: String = "",
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val x2: Float = 0.5f,
    val y2: Float = 0.8f,
    val durationMs: Long = 350L
)

object CommandParser {
    enum class Type {
        STOP, SWIPE_UP, SWIPE_DOWN, TAP_CENTER, CLICK_TEXT,
        OPEN_APP, GO_HOME, GO_BACK, READ_SCREEN, UNKNOWN
    }

    fun parse(input: String): ParsedCommand {
        val raw = input.trim()
        val s = raw.lowercase(Locale.forLanguageTag("tr-TR"))
        if (s.isBlank()) return ParsedCommand(Type.UNKNOWN, "Boş komut")
        if (s in setOf("dur", "durdur", "iptal", "acil durdur", "işlemi kes", "analizi durdur"))
            return ParsedCommand(Type.STOP, "Acil durdur")
        if (s.contains("ana ekrana dön") || s == "ana ekran")
            return ParsedCommand(Type.GO_HOME, "Ana ekrana dön")
        if (s == "geri" || s == "geri dön" || s == "önceki sayfa")
            return ParsedCommand(Type.GO_BACK, "Geri dön")
        if (s.contains("ekranı oku") || s.contains("ekranda ne var") ||
            s.contains("ekrandakileri oku") || s.contains("ekranı anlat"))
            return ParsedCommand(Type.READ_SCREEN, "Ekran metnini oku")
        if (s.contains("yukarı kaydır") || s == "yukarı")
            return ParsedCommand(Type.SWIPE_UP, "Yukarı kaydır", y = 0.25f, y2 = 0.78f)
        if (s.contains("aşağı kaydır") || s == "aşağı")
            return ParsedCommand(Type.SWIPE_DOWN, "Aşağı kaydır", y = 0.78f, y2 = 0.25f)

        val clickPatterns = listOf(
            Regex("(?:ekrandaki\\s+)?(.+?)\\s+(?:yazısına\\s+)?(?:tıkla|bas|seç)$"),
            Regex("(?:şuna|buna)\\s+tıkla\\s*[:：]?\\s*(.+)$")
        )
        for (pattern in clickPatterns) {
            val match = pattern.find(s)
            if (match != null) {
                val target = match.groupValues[1].trim().trim('"', '“', '”', '.', ' ')
                if (target.isNotBlank())
                    return ParsedCommand(Type.CLICK_TEXT, "Ekranda metin bul ve tıkla", target)
            }
        }

        val openMatch = Regex("(.+?)\\s+(?:uygulamasını\\s+)?aç$").find(s)
        if (openMatch != null) {
            val app = openMatch.groupValues[1].trim().removePrefix("lütfen ").trim()
            if (app.isNotBlank()) return ParsedCommand(Type.OPEN_APP, "Uygulama aç", app)
        }
        if (s in setOf("dokun", "ekrana dokun", "ortaya tıkla", "merkeze tıkla"))
            return ParsedCommand(Type.TAP_CENTER, "Ekranın merkezine dokun")
        return ParsedCommand(Type.UNKNOWN, raw)
    }
}

package com.kizilelma.mobile.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.kizilelma.mobile.commands.CommandParser
import com.kizilelma.mobile.commands.ParsedCommand

class KizilAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: KizilAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun execute(command: ParsedCommand): Boolean {
        return when (command.type) {
            CommandParser.Type.TAP_CENTER -> dispatchPoint(0.5f, 0.5f)
            CommandParser.Type.SWIPE_UP, CommandParser.Type.SWIPE_DOWN ->
                dispatchSwipe(command.x, command.y, command.x2, command.y2, command.durationMs)
            CommandParser.Type.CLICK_TEXT -> clickVisibleText(command.argument)
            CommandParser.Type.GO_HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
            CommandParser.Type.GO_BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
            else -> false
        }
    }

    private fun clickVisibleText(target: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(target)
        for (node in nodes) {
            var candidate: AccessibilityNodeInfo? = node
            var depth = 0
            while (candidate != null && depth < 5) {
                if (candidate.isClickable && candidate.isEnabled &&
                    candidate.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                candidate = candidate.parent
                depth++
            }
        }
        return false
    }

    private fun dispatchPoint(nx: Float, ny: Float): Boolean {
        val (width, height) = screenSize()
        val path = Path().apply { moveTo(width * nx, height * ny) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    private fun dispatchSwipe(x: Float, y: Float, x2: Float, y2: Float, duration: Long): Boolean {
        val (width, height) = screenSize()
        val path = Path().apply {
            moveTo(width * x, height * y)
            lineTo(width * x2, height * y2)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration.coerceIn(150, 1200)))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val metrics = DisplayMetrics()
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        return metrics.widthPixels to metrics.heightPixels
    }
}

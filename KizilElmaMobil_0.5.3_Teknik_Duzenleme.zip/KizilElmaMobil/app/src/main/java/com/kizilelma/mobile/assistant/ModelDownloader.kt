package com.kizilelma.mobile.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.Executors

class ModelDownloader(context: Context) {
    interface Listener {
        fun onProgress(percent: Int, downloadedBytes: Long, totalBytes: Long)
        fun onComplete(file: File)
        fun onError(message: String)
    }

    private val appContext = context.applicationContext
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var connection: HttpURLConnection? = null

    fun download(listener: Listener) {
        executor.execute {
            val directory = File(appContext.filesDir, "models")
            if (!directory.exists() && !directory.mkdirs()) {
                postError(listener, "Model klasörü oluşturulamadı")
                return@execute
            }

            val finalFile = File(directory, MODEL_NAME)
            val tempFile = File(directory, "$MODEL_NAME.part")
            try {
                val conn = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20000
                    readTimeout = 30000
                    instanceFollowRedirects = true
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "KizilElmaMobil/0.5.0")
                }
                connection = conn
                conn.connect()
                if (conn.responseCode !in 200..299) {
                    throw IllegalStateException("Model sunucusu HTTP ${conn.responseCode} döndürdü")
                }

                val total = conn.contentLengthLong.takeIf { it > 0 } ?: EXPECTED_SIZE
                var downloaded = 0L
                BufferedInputStream(conn.inputStream).use { input ->
                    FileOutputStream(tempFile).use { output ->
                        val buffer = ByteArray(1024 * 1024)
                        var count: Int
                        var lastPercent = -1
                        while (input.read(buffer).also { count = it } != -1) {
                            output.write(buffer, 0, count)
                            downloaded += count
                            val percent = ((downloaded * 100) / total).toInt().coerceIn(0, 100)
                            if (percent != lastPercent) {
                                lastPercent = percent
                                val currentDownloaded = downloaded
                                main.post { listener.onProgress(percent, currentDownloaded, total) }
                            }
                        }
                        output.fd.sync()
                    }
                }
                conn.disconnect()
                connection = null

                if (downloaded != EXPECTED_SIZE) {
                    throw IllegalStateException("Dosya boyutu doğrulanamadı: $downloaded bayt")
                }
                val digest = sha256(tempFile)
                if (!digest.equals(EXPECTED_SHA256, ignoreCase = true)) {
                    throw SecurityException("Model SHA-256 doğrulaması başarısız")
                }
                if (finalFile.exists() && !finalFile.delete()) {
                    throw IllegalStateException("Eski model dosyası değiştirilemedi")
                }
                if (!tempFile.renameTo(finalFile)) {
                    throw IllegalStateException("İndirilen model dosyası kaydedilemedi")
                }
                main.post { listener.onComplete(finalFile) }
            } catch (error: Exception) {
                try { tempFile.delete() } catch (_: Exception) { }
                postError(listener, error.localizedMessage ?: "Model indirilemedi")
            } finally {
                connection?.disconnect()
                connection = null
            }
        }
    }

    fun cancel() {
        connection?.disconnect()
        executor.shutdownNow()
    }

    private fun postError(listener: Listener, message: String) {
        main.post { listener.onError(message) }
    }

    private fun sha256(file: File): String = calculateSha256(file)

    companion object {
        fun isValidModel(file: File): Boolean {
            if (!file.isFile || file.length() != EXPECTED_SIZE) return false
            return try {
                calculateSha256(file).equals(EXPECTED_SHA256, ignoreCase = true)
            } catch (_: Exception) {
                false
            }
        }

        private fun calculateSha256(file: File): String {
            val digest = MessageDigest.getInstance("SHA-256")
            file.inputStream().buffered().use { input ->
                val buffer = ByteArray(1024 * 1024)
                var count: Int
                while (input.read(buffer).also { count = it } != -1) digest.update(buffer, 0, count)
            }
            return digest.digest().joinToString("") { "%02x".format(it.toInt() and 0xff) }
        }

        const val MODEL_NAME = "Qwen3-0.6B.litertlm"
        const val MODEL_URL = "https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B.litertlm"
        const val EXPECTED_SIZE = 613722264L
        const val EXPECTED_SHA256 = "c5f39b419192678c3e6668b62af4d6eb15248dfc7a5348252a9b406f33f2108"
    }
}

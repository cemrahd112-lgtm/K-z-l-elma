package com.kizilelma.mobile.assistant

import android.content.Context
import java.io.File

object LocalModelStatus {
    fun describe(context: Context): String {
        val model = File(context.filesDir, "models/${ModelDownloader.MODEL_NAME}")
        return if (model.isFile && model.length() == ModelDownloader.EXPECTED_SIZE) {
            "Yerel LLM: Model dosyası mevcut. SHA-256 doğrulaması yükleme sırasında yapılacak."
        } else {
            "Yerel LLM: Model henüz indirilmedi. İlk kurulumda yaklaşık 614 MB indirilir."
        }
    }
}

package com.kizilelma.mobile.memory

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class MemoryEntry(val raw: String, val parsed: String, val createdAt: Long)

class MemoryStore(context: Context) : SQLiteOpenHelper(context, "kizil_elma.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE command_history(id INTEGER PRIMARY KEY AUTOINCREMENT, raw TEXT NOT NULL, parsed TEXT NOT NULL, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_command_history_created ON command_history(created_at)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("CREATE INDEX IF NOT EXISTS idx_command_history_created ON command_history(created_at)")
    }
    fun save(raw: String, parsed: String) {
        val values = ContentValues().apply {
            put("raw", raw.take(1000))
            put("parsed", parsed.take(1000))
            put("created_at", System.currentTimeMillis())
        }
        writableDatabase.insert("command_history", null, values)
    }
    fun recent(limit: Int = 20): List<MemoryEntry> {
        val result = mutableListOf<MemoryEntry>()
        readableDatabase.rawQuery(
            "SELECT raw, parsed, created_at FROM command_history ORDER BY created_at DESC LIMIT ?",
            arrayOf(limit.coerceIn(1, 100).toString())
        ).use { cursor ->
            while (cursor.moveToNext())
                result += MemoryEntry(cursor.getString(0), cursor.getString(1), cursor.getLong(2))
        }
        return result
    }
}
